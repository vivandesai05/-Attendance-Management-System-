from django.apps import AppConfig


class FacultyAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'faculty_app'
